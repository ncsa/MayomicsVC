#!/bin/bash

PrintName=$1

set -x

echo "Hello, World and ${PrintName}!"
